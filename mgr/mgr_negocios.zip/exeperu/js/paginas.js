Helpers.prototype.init = function (datos) {
    var self = this;
    this.dataApp = datos;

    this.table_paginas();
};

Helpers.prototype.table_paginas = function () {
    this.loadDataTable('table_paginas', {
        "lengthMenu": [[50, 75, 100, -1], [50, 75, 100, "Todos"]],
        "pagingType": "full_numbers",
        "ajax": {
            "type": "POST",
            "url": this.dataApp.url,
        },
        "columns": [
            {"data": "pagina"},
            {"data": "url"},
            {"data": "orden"},
            {"data": "estado", "render": function (data) {
                    var salida = '';

                    switch (data) {
                        case '1':
                            salida = '<span class="label label-success">Activo</span>';
                            break;
                        default:
                            salida= '<span class="label label-danger">Inactivo</span>';
                            break;
                    }

                    return salida;
                }
            },
            {"data": "botones"}
        ]
    });
};

Helpers.prototype.delPagina = function (idpagina) {
    if(confirm('Desea eliminar')){
        this.sendAjax('manager/paginas/delete', {"id": idpagina}, 'refrescar');
    }
};

Helpers.prototype.refrescar = function () {
    //$('#modalCreateEdit').modal('toggle');
    this.tables['table_paginas'].ajax.reload();
};

Helpers.prototype.editAutor = function (idautor) {
    this.sendAjax('manager/autores/edit', {"id": idautor}, 'loadResponse');
};

Helpers.prototype.addAutor = function () {
    this.sendAjax('manager/autores/edit', {"idautor": 0}, 'loadResponse');
};

Helpers.prototype.reloadTableAutores = function (response) {
    $('#modalCreateEdit').modal('toggle');

    return this.tables['table_paginas'].ajax.reload();
};



