Helpers.prototype.init = function (datos) {
    var self = this;
    this.dataApp = datos;

    this.table_blogs();
};

Helpers.prototype.table_blogs = function () {
    this.loadDataTable('table_blogs', {
        "lengthMenu": [[50, 75, 100, -1], [50, 75, 100, "Todos"]],
        "pagingType": "full_numbers",
        "ajax": {
            "type": "POST",
            "url": this.dataApp.url,
        },
        "columns": [
            {"data": "titulo"},
//            {"data": "foto"},
            {"data": "imagen", "render": function (data) {
                    var salida = '';

                    salida= '<img src="'+data+'" width="60px;" height="60px;">';
                            
                    return salida;
                }
            },
            {"data": "nombrecompleto"},
            {"data": "fechajm"},
            {"data": "orden"},
            {"data": "estado", "render": function (data) {
                    var salida = '';

                    switch (data) {
                        case '1':
                            salida = '<span class="label label-success">Activo</span>';
                            break;
                        default:
                            salida= '<span class="label label-danger">Inactivo</span>';
                            break;
                    }

                    return salida;
                }
            },
            {"data": "botones"}
        ]
    });
};

Helpers.prototype.delBlog = function (idblog) {
    if(confirm('Desea eliminar')){
        this.sendAjax('manager/blogs/delete', {"id": idblog}, 'refrescar');
    }
};

Helpers.prototype.refrescar = function () {
    //$('#modalCreateEdit').modal('toggle');
    this.tables['table_blogs'].ajax.reload();
};

Helpers.prototype.editBlog = function (idblog) {
    this.sendAjax('manager/blogs/edit', {"id": idblog}, 'loadResponse');
};

Helpers.prototype.addBlog = function () {
    this.sendAjax('manager/blogs/edit', {"idblog": 0}, 'loadResponse');
};

Helpers.prototype.reloadTableBlogs = function (response) {
    $('#modalCreateEdit').modal('toggle');

    return this.tables['table_blogs'].ajax.reload();
};



