Helpers.prototype.init = function (datos) {
    var self = this;
    this.dataApp = datos;

    this.table_autores();
};

Helpers.prototype.table_autores = function () {
    this.loadDataTable('table_autores', {
        "lengthMenu": [[50, 75, 100, -1], [50, 75, 100, "Todos"]],
        "pagingType": "full_numbers",
        "ajax": {
            "type": "POST",
            "url": this.dataApp.url,
        },
        "columns": [
            {"data": "nombres"},
            {"data": "apellidos"},
//            {"data": "foto"},
            {"data": "foto", "render": function (data) {
                    var salida = '';

                    salida= '<img src="'+data+'" width="60px;" height="60px;">';
                            
                    return salida;
                }
            },
            {"data": "estado", "render": function (data) {
                    var salida = '';

                    switch (data) {
                        case '1':
                            salida = '<span class="label label-success">Activo</span>';
                            break;
                        default:
                            salida= '<span class="label label-danger">Inactivo</span>';
                            break;
                    }

                    return salida;
                }
            },
            {"data": "botones"}
        ]
    });
};

Helpers.prototype.delAutor = function (idautor) {
    if(confirm('Desea eliminar')){
        this.sendAjax('manager/autores/delete', {"id": idautor}, 'refrescar');
    }
};

Helpers.prototype.refrescar = function () {
    //$('#modalCreateEdit').modal('toggle');
    this.tables['table_autores'].ajax.reload();
};

Helpers.prototype.editAutor = function (idautor) {
    this.sendAjax('manager/autores/edit', {"id": idautor}, 'loadResponse');
};

Helpers.prototype.addAutor = function () {
    this.sendAjax('manager/autores/edit', {"idautor": 0}, 'loadResponse');
};

Helpers.prototype.reloadTableAutores = function (response) {
    $('#modalCreateEdit').modal('toggle');

    return this.tables['table_autores'].ajax.reload();
};



